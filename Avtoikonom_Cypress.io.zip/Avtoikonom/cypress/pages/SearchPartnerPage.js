import { faker } from "@faker-js/faker";
import 'cypress-iframe';
import 'cypress-file-upload';

export class SearchPartnerPage {

// Search for partner and edit
    searchForPartnerAndEdit ()
    {
       //Click on the search field and enter the partner name
        cy.wait(2000);
        cy.get('.TCIJK').should("be.visible").click({ force: true });
        cy.get('.TCIJK').type("AutoP");
        
        //Click on the three dots and select Edit
        cy.get('#action-button').click();
        cy.get('#edit-button').should("be.visible").click();
        
        //Edit Field - Contact Person and save
        cy.get('#contact-person-field').clear().type("Petar Mihaylov");
        
        //Click Save 
        cy.get('#save-button').click({ force: true });
        cy.wait(2000);
    }

};
